//
//  CS5520FinalProject_Group6Tests.swift
//  CS5520FinalProject_Group6Tests
//
//  Created by NIKITA LIANG on 11/18/24.
//

import Testing
@testable import CS5520FinalProject_Group6

struct CS5520FinalProject_Group6Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
