//
//  ViewController.swift
//  CS5520FinalProject_Group6
//
//  Created by NIKITA LIANG on 11/18/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

